from artiq.experiment import *
import Constants
import Variables
import DAC_config
import pandas as pd
import numpy as np


class DAC(EnvExperiment):

    def build(self):
        self.setattr_device('core')
        self.setattr_device('zotino0')

        Variables.Variables.build_load_DAC(self)
        Constants.Constants.build_DAC(self)
    
    def run(self):
        self.core.reset()
        self.load_DAC()

    def load_DAC(self):
        DAC_config.DAC_config.loadDACoffset(self)
        dac_pins, dac_pins_voltages = self.get_dac_vs()
        self.kernel_load_dac(dac_pins, dac_pins_voltages)
    
    @ kernel
    def kernel_load_dac(self,dac_pins, dac_pins_voltages):
        self.core.reset()
        self.core.break_realtime()
        self.zotino0.init()
        for i in range(len(dac_pins)):
            delay(500*us)
            m = self.dac_calibration_fit[1][dac_pins[i]]
            b = self.dac_calibration_fit[0][dac_pins[i]]
            self.zotino0.write_dac(dac_pins[i],(dac_pins_voltages[i]+b)/m - self.dac_manual_offset[dac_pins[i]])
        for pin in self.gnd:
            delay(500*us)
            self.zotino0.write_dac(pin,0.0)
            m = self.dac_calibration_fit[1][pin]
            b = self.dac_calibration_fit[0][pin]
            self.zotino0.write_offset(pin,-b/m)
        self.zotino0.load()
        # print("Loaded dac voltages")

    def get_dac_vs(self):
        dac_vs = {}
        dac_pins = []
        dac_pins_voltages = []

        if self.multipole_control:
            dac_vs = self.update_multipoles()
        else:
            for e in self.pin_matching:
                dac_vs[e] = getattr(self,e)
        
        for e in dac_vs:
            dac_pins.append(self.pin_matching[e])
            dac_pins_voltages.append(dac_vs[e])
        
        self.set_DC_dataset(dac_vs)
        return dac_pins, dac_pins_voltages
    
    @rpc(flags={"async"})
    def set_DC_dataset(self,dac_vs):
        for e in dac_vs:
            self.set_dataset(key="main_sequence.e."+e, value=dac_vs[e], broadcast=True)
    
    @rpc(flags={"async"})
    def set_multipole_dataset(self,dac_ms):
        for m in dac_ms:
            self.set_dataset(key="main_sequence.multipole."+m, value=dac_ms[m], broadcast=True)

    def update_multipoles(self):
        
        # Create multiple list of floats
        dac_ms = {}
        for m in self.controlled_multipoles:
            dac_ms[m] = getattr(self,m)
        self.set_multipole_dataset(dac_ms)
        
        if not self.grid:
            df = pd.read_csv(self.c_file_csv,index_col = 0)
            voltages = pd.Series(np.zeros(len(self.pin_matching.keys())-len(self.excess_e)),index = df.index.values)
            print("Multipoles:",dac_ms)
            for m in self.controlled_multipoles:   
                voltages += df[m] * dac_ms[m]
            dac_vs = voltages.to_dict()
            for e in self.excess_e:
                dac_vs[e] = getattr(self,e)
            # for e in dac_vs:
            #     dac_vs[e] = round(dac_vs[e],3)    
            print(dac_vs)
            return dac_vs

        else:
            #FIXME
            df = pd.read_csv(self.c_file_csv,index_col = 0)
            voltages = pd.Series(np.zeros(len(self.pin_matching.keys())-len(self.excess_e)),index = df.index.values)

            # V_grid = self.mul_dict["Grid"]
            # print("V_grid:",V_grid)
            # for m in self.controlled_multipoles:   
            #     if m == "Grid":
            #         pass
            #     else:
            #         self.mul_dict[m] = self.mul_dict[m] - grid_m[m]*V_grid/150
            #         # voltages += df[m] * self.mul_dict[m]
            # Calculate and print electrode values
            for m in self.controlled_multipoles:   
                if m == "Grid":
                    pass
                else:
                    # self.mul_dict[m] = self.mul_dict[m] - grid_m[m]*V_grid
                    voltages += df[m] * self.mul_dict[m]
            self.elec_dict = voltages.to_dict()
            self.elec_dict["trigger_level"] = self.parameter_dict["trigger_level"]
            for e in self.elec_dict:
                self.elec_dict[e] = round(self.elec_dict[e],3)    
            print(self.elec_dict)

            for e in self.controlled_electrodes:
                if e == "trigger_level":
                    pass
                else:
                    self.electrode_labels[e].setText(str(round(self.elec_dict[e],3)))      
            self.mutate_dataset_electrode()

            self.mul_list = []
            for m in self.HasEnvironment.controlled_multipoles[1:]:
                self.mul_list.append(self.mul_dict[m])
            # grid_m = {'C': 0.019940897983726433,'Ey': -3.360905574255682e-05,'Ez': 0.00022449376590844223,'Ex': 0.06399536424651765,'U3': 0.13434433573433666,'U4': 0.0011390387152830977,'U2': 0.03015271954151855,'U5': -0.021575389610886914,'U1': 0.050389617844847405}
            # V_grid = self.mul_dict["Grid"]
            # print("V_grid:",V_grid)
            # for m in self.controlled_multipoles:   
            #     if m == "Grid":
            #         pass
            #     else:
            #         self.mul_dict[m] = self.mul_dict[m] - grid_m[m]*V_grid/150
            #         # voltages += df[m] * self.mul_dict[m]
            # Calculate and print electrode values
            try:
                
                self.m=np.array([self.mul_list])
                self.grid_multipole_150V = np.array([0.0203082,0.00042961,-0.00124763,-0.047735,-0.00441363,0.00081879,0.00012903,-0.03539802,-0.00083521])
                self.grid_multipole_150V = self.grid_multipole_150V[0:len(self.HasEnvironment.controlled_multipoles)-1]
                grid_multipole = [g*grid_V/150 for g in self.grid_multipole_150V]
                self.m=self.m-grid_multipole
                self.e=np.matmul(self.m, self.C_Matrix_np)
            except:
                f = open('/home/electron/artiq-nix/electron/Cfile_3layer.txt','r')
                # create list of lines from selected textfile
                self.list_of_lists = []
                for line in f:
                    stripped_line = line.strip()
                    line_list = stripped_line.split()
                    self.list_of_lists.append(float(line_list[0]))
                    
                # create list of values from size 21*9 C-file
                curr_elt = 0
                self.C_Matrix = []
                for i in range(len(self.HasEnvironment.controlled_multipoles)-1):
                    C_row = []
                    for i in range(self.ne-1): #-1 because of the channel 0 for trigger level
                        C_row.append(self.list_of_lists[curr_elt])
                        curr_elt+=1
                    self.C_Matrix.append(C_row) 
                    
                self.C_Matrix_np = np.array(self.C_Matrix)
                self.m=np.array([self.mul_list])
                #print(shape(self.m))
                # grid_V = 150
                self.grid_multipole_150V = np.array([0.0203082,0.00042961,-0.00124763,-0.047735,-0.00441363,0.00081879,0.00012903,-0.03539802,-0.00083521])
                self.grid_multipole_150V = self.grid_multipole_150V[0:len(self.HasEnvironment.controlled_multipoles)-1]
                grid_multipole = [g*grid_V/150 for g in self.grid_multipole_150V]
                self.m=self.m-grid_multipole
                self.e=np.matmul(self.m, self.C_Matrix_np)
                
            for i in range(len(self.e[0])):
                if self.e[0][i]>=self.HasEnvironment.max_voltage:
                    print(f'warning: voltage {round(self.e[0][i],3)}  exceeds limit')
                    self.e[0][i]=self.HasEnvironment.max_voltage
                elif self.e[0][i]<=-self.HasEnvironment.max_voltage:
                    print(f'warning: voltage {round(self.e[0][i],3)} exceeds limit')
                    self.e[0][i]=-self.HasEnvironment.max_voltage

            self.e = self.e[0].tolist()
            #self.e.append(self.e.pop(10))      
            for i in range(len(self.e)):
                self.e[i]=round(self.e[i],3)
            print("self.e:",self.e)

            

            
            #self.e is in alphabetical order as in c file: [bl1,...,bl5,br1,...,br5, tg("grid"),tl1,...,tl5,tr1,..,tr5]
            self.elec_dict={'bl1':self.e[0],'bl2':self.e[1],'bl3':self.e[2],'bl4':self.e[3],'bl5':self.e[4],'br1':self.e[5],'br2':self.e[6],'br3':self.e[7],'br4':self.e[8],'br5':self.e[9],'tg':self.e[10],'tl1':self.e[11],'tl2':self.e[12],'tl3':self.e[13],'tl4':self.e[14],'tl5':self.e[15],'tr1':self.e[16],'tr2':self.e[17],'tr3':self.e[18],'tr4':self.e[19],'tr5':self.e[20]}
            # print(self.elec_dict)
            

            for e in self.electrode_labels:
                self.electrode_labels[e].setText(str(round(self.elec_dict[e],3)))      
            self.mutate_dataset_electrode()




















